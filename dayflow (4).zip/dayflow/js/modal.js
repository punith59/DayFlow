const backdrop = document.getElementById("sheet-backdrop");
const sheet = document.getElementById("sheet");

export function notifyChanged() {
  document.dispatchEvent(new CustomEvent("dayflow:refresh"));
}

export function closeSheet() {
  sheet.classList.add("hidden");
  backdrop.classList.add("hidden");
  sheet.innerHTML = "";
}

function openSheet(html) {
  sheet.innerHTML = html;
  sheet.classList.remove("hidden");
  backdrop.classList.remove("hidden");
}

backdrop.addEventListener("click", closeSheet);

export function openAddMenu() {
  openSheet(`
    <button class="icon-btn sheet-close" data-action="close" aria-label="Close">✕</button>
    <h2 class="sheet-title">Add</h2>
    <p class="placeholder-text">We're building each section one at a time — task, event, journal,
    goal, and note creation will land here once their sections are ready.</p>
  `);
  sheet.querySelector('[data-action="close"]').addEventListener("click", closeSheet);
}
