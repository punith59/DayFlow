import { uid, WEEKDAY_NAMES } from "./utils.js";

const KEYS = {
  tasks: "dayflow:tasks",
  events: "dayflow:events",
  goals: "dayflow:goals",
  memories: "dayflow:memories",
  notes: "dayflow:notes",
  college: "dayflow:college",
  settings: "dayflow:settings",
};

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw == null) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.warn("DayFlow: failed to read", key, e);
    return fallback;
  }
}

function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.warn("DayFlow: failed to save", key, e);
    return false;
  }
}

function emptyCollege() {
  const c = {};
  WEEKDAY_NAMES.forEach((d) => (c[d] = []));
  return c;
}

export const store = {
  // ---- Tasks ----
  getTasks() { return read(KEYS.tasks, []); },
  saveTasks(list) { return write(KEYS.tasks, list); },
  addTask(task) {
    const list = store.getTasks();
    list.push({ id: uid(), done: false, priority: 5, ...task });
    store.saveTasks(list);
  },
  updateTask(id, patch) {
    const list = store.getTasks().map((t) => (t.id === id ? { ...t, ...patch } : t));
    store.saveTasks(list);
  },
  deleteTask(id) {
    store.saveTasks(store.getTasks().filter((t) => t.id !== id));
  },

  // ---- Events ----
  getEvents() { return read(KEYS.events, []); },
  saveEvents(list) { return write(KEYS.events, list); },
  addEvent(evt) {
    const list = store.getEvents();
    list.push({ id: uid(), ...evt });
    store.saveEvents(list);
  },
  updateEvent(id, patch) {
    const list = store.getEvents().map((e) => (e.id === id ? { ...e, ...patch } : e));
    store.saveEvents(list);
  },
  deleteEvent(id) {
    store.saveEvents(store.getEvents().filter((e) => e.id !== id));
  },

  // ---- Goals ----
  getGoals() { return read(KEYS.goals, []); },
  saveGoals(list) { return write(KEYS.goals, list); },
  addGoal(goal) {
    const list = store.getGoals();
    list.push({ id: uid(), ...goal });
    store.saveGoals(list);
  },
  updateGoal(id, patch) {
    const list = store.getGoals().map((g) => (g.id === id ? { ...g, ...patch } : g));
    store.saveGoals(list);
  },
  deleteGoal(id) {
    store.saveGoals(store.getGoals().filter((g) => g.id !== id));
    // detach tasks from the deleted goal, don't delete the tasks
    const tasks = store.getTasks().map((t) => (t.goalId === id ? { ...t, goalId: null } : t));
    store.saveTasks(tasks);
  },
  goalProgress(goalId) {
    const tasks = store.getTasks().filter((t) => t.goalId === goalId);
    if (tasks.length === 0) return 0;
    const done = tasks.filter((t) => t.done).length;
    return Math.round((done / tasks.length) * 100);
  },

  // ---- Memories (keyed by date) ----
  getMemories() { return read(KEYS.memories, {}); },
  saveMemories(obj) { return write(KEYS.memories, obj); },
  getMemory(dateKey) {
    const all = store.getMemories();
    return all[dateKey] || { date: dateKey, text: "", mood: null, updatedAt: null };
  },
  saveMemory(dateKey, patch) {
    const all = store.getMemories();
    const existing = all[dateKey] || { date: dateKey, text: "", mood: null };
    all[dateKey] = { ...existing, ...patch, updatedAt: Date.now() };
    store.saveMemories(all);
  },

  // ---- Notes (permanent, separate from daily memory) ----
  getNotes() { return read(KEYS.notes, []); },
  saveNotes(list) { return write(KEYS.notes, list); },
  addNote(note) {
    const list = store.getNotes();
    list.unshift({ id: uid(), createdAt: Date.now(), ...note });
    store.saveNotes(list);
  },
  deleteNote(id) {
    store.saveNotes(store.getNotes().filter((n) => n.id !== id));
  },

  // ---- College schedule ----
  getCollege() {
    const c = read(KEYS.college, null);
    return c || emptyCollege();
  },
  saveCollege(obj) { return write(KEYS.college, obj); },

  // ---- Settings ----
  getSettings() { return read(KEYS.settings, { accent: "#34C77B" }); },
  saveSettings(obj) { return write(KEYS.settings, obj); },

  // ---- Export / Import ----
  exportAll() {
    return {
      version: 1,
      exportedAt: new Date().toISOString(),
      tasks: store.getTasks(),
      events: store.getEvents(),
      goals: store.getGoals(),
      memories: store.getMemories(),
      notes: store.getNotes(),
      college: store.getCollege(),
      settings: store.getSettings(),
    };
  },
  importAll(data) {
    if (!data || typeof data !== "object") throw new Error("Invalid file");
    if (data.tasks) store.saveTasks(data.tasks);
    if (data.events) store.saveEvents(data.events);
    if (data.goals) store.saveGoals(data.goals);
    if (data.memories) store.saveMemories(data.memories);
    if (data.notes) store.saveNotes(data.notes);
    if (data.college) store.saveCollege(data.college);
    if (data.settings) store.saveSettings(data.settings);
  },
};
