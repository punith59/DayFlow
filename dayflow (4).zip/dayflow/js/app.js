import { store } from "./store.js";
import { onRouteChange, initRouter, currentRoute, navigate } from "./router.js";
import { openAddMenu } from "./modal.js";
import { renderToday } from "./screens/today.js";
import { renderCalendar } from "./screens/calendar.js";
import { renderMemory } from "./screens/memory.js";
import { renderGoals } from "./screens/goals.js";
import { renderMore } from "./screens/more.js";

const SCREENS = [
  { id: "today", label: "Today", icon: "○", render: renderToday },
  { id: "calendar", label: "Calendar", icon: "▦", render: renderCalendar },
  { id: "memory", label: "Journal", icon: "◐", render: renderMemory },
  { id: "goals", label: "Goals", icon: "◎", render: renderGoals },
  { id: "more", label: "More", icon: "⋯", render: renderMore },
];

const view = document.getElementById("view");
const navBar = document.getElementById("nav-bar");
const fab = document.getElementById("fab");

function navItemHtml(screen, active) {
  return `<button class="nav-item ${active ? "active" : ""}" data-nav="${screen.id}">
    <span class="nav-icon">${screen.icon}</span>
    <span>${screen.label}</span>
  </button>`;
}

function renderNav(activeId) {
  navBar.innerHTML = SCREENS.map((s) => navItemHtml(s, s.id === activeId)).join("");
  navBar.querySelectorAll("[data-nav]").forEach((el) => {
    el.addEventListener("click", () => navigate(el.getAttribute("data-nav")));
  });
}

function renderScreen(route) {
  const screen = SCREENS.find((s) => s.id === route.screen) || SCREENS[0];
  renderNav(screen.id);
  try {
    screen.render(view);
  } catch (err) {
    console.error("DayFlow render error:", err);
    view.innerHTML = `<p class="empty-note">Something went wrong loading this screen. Try switching tabs and back.</p>`;
  }
  window.scrollTo(0, 0);
}

function renderCurrentScreen() {
  renderScreen(currentRoute());
}

// Apply saved accent color
const settings = store.getSettings();
if (settings.accent) {
  document.documentElement.style.setProperty("--accent", settings.accent);
}

onRouteChange(renderScreen);
initRouter();

fab.addEventListener("click", openAddMenu);

document.addEventListener("dayflow:refresh", renderCurrentScreen);

// ---- PWA install prompt ----
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  window.__dayflowInstallPrompt = e;
});

// ---- Service worker ----
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    const swUrl = new URL("./sw.js", document.baseURI).toString();
    navigator.serviceWorker.register(swUrl).catch((err) => {
      console.warn("DayFlow: service worker registration failed", err);
    });
  });
}
