export function renderGoals(container) {
  container.innerHTML = `
    <h1 class="page-date">Goals</h1>
    <p class="page-summary">Collections of tasks working toward something.</p>

    <div class="placeholder-panel">
      <div class="placeholder-icon">◎</div>
      <div class="placeholder-title">Goals</div>
      <p class="placeholder-text">Your goals and their progress will live here, with a focused<br>view of the tasks tied to each one.</p>
    </div>
  `;
}
