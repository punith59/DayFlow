export function renderMore(container) {
  container.innerHTML = `
    <h1 class="page-date">More</h1>

    <div class="placeholder-panel">
      <div class="placeholder-icon">⋯</div>
      <div class="placeholder-title">More</div>
      <p class="placeholder-text">Appearance, College Schedule, Install, and Data Export/Import<br>will live here.</p>
    </div>
  `;
}
