import { prettyDate, greeting, dateKey } from "../utils.js";

export function renderToday(container) {
  const today = dateKey();
  container.innerHTML = `
    <h1 class="page-date">${prettyDate(today)}</h1>
    <p class="page-greeting">${greeting()}</p>

    <div class="placeholder-panel">
      <div class="placeholder-icon">○</div>
      <div class="placeholder-title">Today</div>
      <p class="placeholder-text">Your day's timeline will live here — tasks, events, and college<br>classes laid out in order, with real gaps for free time.</p>
    </div>
  `;
}
