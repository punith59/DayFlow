export function renderMemory(container) {
  container.innerHTML = `
    <h1 class="page-date">Journal</h1>
    <p class="page-summary">A place to look back.</p>

    <div class="placeholder-panel">
      <div class="placeholder-icon">◐</div>
      <div class="placeholder-title">Journal</div>
      <p class="placeholder-text">Today's entry, your mood, and an archive of past days<br>will live here — plus a separate space for permanent notes.</p>
    </div>
  `;
}
