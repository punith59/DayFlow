export function renderCalendar(container) {
  container.innerHTML = `
    <h1 class="page-date">Calendar</h1>
    <p class="page-summary">Your weekly timeline.</p>

    <div class="placeholder-panel">
      <div class="placeholder-icon">▦</div>
      <div class="placeholder-title">Calendar</div>
      <p class="placeholder-text">A weekly timeline view will live here — days across the top,<br>hours down the side, everything on one continuous grid.</p>
    </div>
  `;
}
