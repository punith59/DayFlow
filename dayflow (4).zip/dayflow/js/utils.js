export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export function pad2(n) { return String(n).padStart(2, "0"); }

export function dateKey(d = new Date()) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

export function keyToDate(key) {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function addDays(key, delta) {
  const d = keyToDate(key);
  d.setDate(d.getDate() + delta);
  return dateKey(d);
}

export function startOfWeek(key) {
  const d = keyToDate(key);
  const day = d.getDay(); // 0 = Sunday
  d.setDate(d.getDate() - day);
  return dateKey(d);
}

export function weekDays(weekStartKey) {
  const out = [];
  for (let i = 0; i < 7; i++) out.push(addDays(weekStartKey, i));
  return out;
}

export const WEEKDAY_NAMES = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
export const WEEKDAY_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
export const MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export function prettyDate(key) {
  const d = keyToDate(key);
  return `${WEEKDAY_LONG[d.getDay()]}, ${MONTH_NAMES[d.getMonth()]} ${d.getDate()}`;
}
const WEEKDAY_LONG = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

export function formatTime(t) {
  if (!t) return "";
  const [h, m] = t.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${pad2(m)} ${period}`;
}

export function timeToMinutes(t) {
  if (!t) return null;
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

export function minutesBetween(t1, t2) {
  const a = timeToMinutes(t1), b = timeToMinutes(t2);
  if (a == null || b == null) return null;
  return b - a;
}

export function escapeHtml(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function greeting() {
  const h = new Date().getHours();
  if (h < 5) return "Still up?";
  if (h < 12) return "Good morning.";
  if (h < 17) return "Good afternoon.";
  if (h < 21) return "Good evening.";
  return "Winding down?";
}

export const PALETTE = [
  "#34C77B", "#4FA3E3", "#E3B34F", "#E36B9E",
  "#9B7BE0", "#4FD1C5", "#E3854F", "#7BE0A0",
  "#6E9BE0", "#D0D0C8",
];

export const TASK_EMOJIS = ["📌","📝","💪","📚","🍽️","🧹","💻","🎯","☎️","🧘","🛒","🎨","💤","✈️","💰"];
export const EVENT_EMOJIS = ["📅","🏫","🧪","📄","🤝","🎤","⚕️","✈️","🎓","⏰"];
export const GOAL_EMOJIS = ["🎯","🌱","🏆","📈","🔥","💡","🧗","📖"];
export const MOODS = ["😊","😐","😞","😴","🥳","😤","😌","🤔"];

export function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}
