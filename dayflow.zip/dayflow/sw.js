const CACHE_NAME = "dayflow-cache-v25";
const SCOPE_URL = new URL(self.registration.scope);

const PRECACHE_URLS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./css/style.css",
  "./js/app.js",
  "./js/router.js",
  "./js/store.js",
  "./js/utils.js",
  "./js/version.js",
  "./js/goals.js",
  "./js/notebooks.js",
  "./js/richtext.js",
  "./js/components/notePage.js",
  "./js/components/noteSheet.js",
  "./js/timeblocks.js",
  "./js/modal.js",
  "./js/forms.js",
  "./js/components/sheet.js",
  "./js/components/dayNav.js",
  "./js/components/swipe.js",
  "./js/components/toast.js",
  "./js/components/actionMenu.js",
  "./js/components/overview.js",
  "./js/components/popover.js",
  "./js/components/blockSheet.js",
  "./js/components/goalSheet.js",
  "./js/components/colorPicker.js",
  "./js/screens/today.js",
  "./js/screens/calendar.js",
  "./js/screens/diary.js",
  "./js/screens/goals.js",
  "./js/screens/more.js",
  "./js/screens/timeBlocks.js",
  "./js/screens/palette.js",
  "./js/screens/backup.js",
  "./icons/icon.svg",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./img/bg.jpg",
].map((p) => new URL(p, SCOPE_URL).toString());

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Network-first for navigation requests (so updates are picked up), cache-first for assets.
self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
          return res;
        })
        .catch(() => caches.match(req).then((res) => res || caches.match(new URL("./index.html", SCOPE_URL).toString())))
    );
    return;
  }

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
          return res;
        })
        .catch(() => cached);
    })
  );
});
